document.getElementsByTagName('h1')[0].onmouseout =
function(){
this.innerText='Active Heading';this.style.color='Black' }